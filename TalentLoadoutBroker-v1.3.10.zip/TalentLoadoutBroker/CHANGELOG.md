# Talent Loadout Broker

## [v1.3.10](https://github.com/NumyAddon/TalentLoadoutBroker/tree/v1.3.10) (2025-08-25)
[Full Changelog](https://github.com/NumyAddon/TalentLoadoutBroker/compare/v1.3.9...v1.3.10) [Previous Releases](https://github.com/NumyAddon/TalentLoadoutBroker/releases)

- Automatically cancel druid flightform when attempting to respec (closes #8)  
