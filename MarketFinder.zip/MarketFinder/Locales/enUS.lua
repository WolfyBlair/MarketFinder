local L = LibStub("AceLocale-3.0"):NewLocale("MarketFinder", "enUS", true)

if not L then return end

L["Market Finder"] = true
L["Find markets and auction houses in World of Warcraft"] = true
L["Shopping Lists"] = true
L["Price Alerts"] = true
L["Auto-Buy"] = true
L["Auto-Sell"] = true -- New: Auto-Sell tab
L["Settings"] = true
L["Search"] = true
L["Create List"] = true
L["Add Alert"] = true
L["Add Rule"] = true
L["Enable Auto Scan"] = true
L["Show Minimap Icon"] = true
L["Enable Auto-Buy"] = true
L["Enable Auto-Sell"] = true -- New: Enable auto-sell setting
L["Max Auto-Buy Price:"] = true
L["Min Auto-Sell Price:"] = true -- New: Min sell price setting
L["Auto-Buy Stack Size:"] = true
L["Auto-Sell Stack Size:"] = true -- New: Sell stack size setting
L["Accept Below Market (%):"] = true -- New: Accept below setting