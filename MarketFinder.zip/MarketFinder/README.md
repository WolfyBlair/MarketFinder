# MarketFinder WoW Addon

MarketFinder is a World of Warcraft addon that helps you find the best markets for buying and selling items.

## Features

- Search for market prices across different vendors
- Track favorite items
- View search history
- Shopping list management
- Price alerts
- Auto-buy when prices drop
- Auto-sell rare items to players
- Auto-scanning
- Minimap icon
- Export functionality
- User-friendly interface with tabs
- Chat commands for quick access

## Installation

1. Download the MarketFinder folder
2. Copy it to your World of Warcraft addons folder:
   - Retail: `World of Warcraft/_retail_/Interface/AddOns/`
   - Classic: `World of Warcraft/_classic_/Interface/AddOns/`
3. Restart World of Warcraft or reload your UI with `/reload`

## Usage

### Chat Commands

- `/mf` or `/marketfinder` - Show help
- `/mf find [item]` - Find markets for a specific item
- `/mf list` - List nearby markets
- `/mf ui` or `/mfui` - Toggle the MarketFinder UI
- `/mf favorites` - List your favorite items
- `/mf shopping` - Manage shopping lists
- `/mf alerts` - Manage price alerts
- `/mf autobuy` - Manage auto-buy rules
- `/mf autosell` - Manage auto-sell rules
- `/mf settings` - Configure addon settings
- `/mf export` - Export data

### User Interface

You can also use the graphical interface by typing `/mf ui` or clicking the minimap icon.

The UI has six tabs:
1. **Search** - Search for items and view results
2. **Shopping Lists** - Create and manage shopping lists
3. **Price Alerts** - Set up price notifications
4. **Auto-Buy** - Configure automatic purchasing
5. **Auto-Sell** - Configure automatic selling
6. **Settings** - Configure addon behavior

#### Search Tab
1. Enter an item name in the search box
2. Click "Search" or press Enter
3. View the market data in the results area

#### Shopping Lists Tab
1. Enter a name and click "Create List"
2. Add items to your shopping lists
3. Search for all items in a list at once

#### Price Alerts Tab
1. Enter an item name and target price
2. Click "Add Alert"
3. Get notified when items reach target prices

#### Auto-Buy Tab
1. Enter an item name and target price
2. Click "Add Rule"
3. The addon will automatically purchase items when they drop to your target price

#### Auto-Sell Tab
1. Enter an item name and target price
2. Click "Add Rule"
3. The addon will automatically sell items to players who offer to buy them

#### Settings Tab
- Enable/disable auto scanning
- Set scan interval
- Show/hide minimap icon
- Enable/disable auto-buy feature
- Set maximum auto-buy price
- Set auto-buy stack size
- Enable/disable auto-sell feature
- Set minimum auto-sell price
- Set auto-sell stack size
- Set percentage below market to accept

## New Features Explained

### Shopping Lists
Create multiple shopping lists to track items you're interested in. You can search for all items in a list at once to compare prices across vendors.

### Price Alerts
Set price alerts for items you want to buy or sell. The addon will notify you when items reach your target prices.

### Auto-Buy
Set auto-buy rules for items you want to purchase automatically when they drop to a target price. The addon will:
- Monitor market prices for your specified items
- Automatically purchase items when they drop to or below your target price
- Respect your maximum price limits and stack size preferences
- Only purchase when you have sufficient funds

### Auto-Sell
Set auto-sell rules for items you want to sell automatically to players who offer to buy them. The addon will:
- Monitor incoming trade requests and whispers
- Automatically sell rare items to players who offer to buy them
- Accept offers based on your configured percentage of market value
- Respect your minimum price limits and stack size preferences
- Only sell items you actually have in your inventory

### Auto Scanning
Enable automatic market scanning at set intervals to keep your data up to date.

### Minimap Icon
Access the addon quickly through the minimap icon:
- Left-click: Toggle UI
- Right-click: Show help

### Export Functionality
Export your favorite items, search history, and price data for external use.

## How It Works

MarketFinder gathers data from various sources:
- Auction House listings
- Player vendors
- Guild banks
- Trade channels

The addon compares prices across different vendors to help you find the best deals.

## Configuration

MarketFinder saves your settings, favorite items, shopping lists, price alerts, auto-buy rules, and auto-sell rules between sessions. Data is stored in your SavedVariables file.

## Support

For issues, suggestions, or contributions, please visit our project page or contact the author.

## Disclaimer

This addon is for educational purposes and demonstrates addon development techniques. In a real implementation, it would need to interact with WoW's APIs to gather actual market data and execute purchases/sales.