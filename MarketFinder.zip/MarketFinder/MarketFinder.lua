-- MarketFinder.lua
-- Main file for MarketFinder addon

MarketFinder = LibStub("AceAddon-3.0"):NewAddon("MarketFinder", "AceConsole-3.0", "AceEvent-3.0", "AceTimer-3.0")
local L = LibStub("AceLocale-3.0"):GetLocale("MarketFinder", true)

-- Check for optional libraries
local ldb = LibStub("LibDataBroker-1.1", true)
local ldbIcon = LibStub("LibDBIcon-1.0", true)

-- Database defaults
local defaults = {
    profile = {
        minimap = {
            hide = false,
        },
        favoriteItems = {},
        searchHistory = {},
        shoppingLists = {},
        priceAlerts = {},
        autoBuyRules = {},
        autoSellRules = {}, -- New: Auto-sell rules
        settings = {
            autoScan = false,
            scanInterval = 30, -- minutes
            showMinimapIcon = true,
            enableAutoBuy = false,
            maxAutoBuyPrice = 1000000, -- 100 gold
            autoBuyStackSize = 1,
            enableAutoSell = false, -- New: Enable auto-sell feature
            minSellPrice = 10000, -- New: Minimum price to auto-sell (1 gold)
            autoSellStackSize = 1, -- New: Number of items to sell at once
            acceptBelowMarket = 0.8, -- New: Accept offers below market (80% of market value)
        }
    }
}

-- Market data storage
MarketFinder.marketData = {}
MarketFinder.currentSearch = nil
MarketFinder.scanTimer = nil
MarketFinder.priceHistory = {}
MarketFinder.autoBuyTimer = nil
MarketFinder.autoSellTimer = nil -- New: Timer for auto-sell checks

-- Initialize the addon
function MarketFinder:OnInitialize()
    -- Set up the database
    self.db = LibStub("AceDB-3.0"):New("MarketFinderDB", defaults, true)
    
    -- Set up the chat command
    self:RegisterChatCommand("marketfinder", "ChatCommand")
    self:RegisterChatCommand("mf", "ChatCommand")
    
    -- Initialize minimap icon
    self:InitializeMinimapIcon()
end

-- Enable the addon
function MarketFinder:OnEnable()
    -- Addon is enabled
    self:Print("MarketFinder addon enabled. Type /mf help for commands.")
    
    -- Register events
    self:RegisterEvent("PLAYER_LOGIN", "OnPlayerLogin")
    self:RegisterEvent("AUCTION_HOUSE_SHOW", "OnAuctionHouseShow")
    self:RegisterEvent("AUCTION_HOUSE_CLOSED", "OnAuctionHouseClosed")
    self:RegisterEvent("PLAYER_LOGOUT", "OnPlayerLogout")
    self:RegisterEvent("CHAT_MSG_WHISPER", "OnWhisper") -- New: Listen for whispers
    self:RegisterEvent("TRADE_REQUEST", "OnTradeRequest") -- New: Listen for trade requests
    
    -- Start auto scan timer if enabled
    if self.db.profile.settings.autoScan then
        self:StartAutoScan()
    end
    
    -- Start auto-buy timer if enabled
    if self.db.profile.settings.enableAutoBuy then
        self:StartAutoBuyTimer()
    end
    
    -- Start auto-sell timer if enabled
    if self.db.profile.settings.enableAutoSell then
        self:StartAutoSellTimer()
    end
end

-- Disable the addon
function MarketFinder:OnDisable()
    -- Cancel any running timers
    if self.scanTimer then
        self:CancelTimer(self.scanTimer)
    end
    if self.autoBuyTimer then
        self:CancelTimer(self.autoBuyTimer)
    end
    if self.autoSellTimer then
        self:CancelTimer(self.autoSellTimer)
    end
end

-- Handle player logout
function MarketFinder:OnPlayerLogout()
    -- Save any pending data
    self:SavePriceHistory()
end

-- New: Handle incoming whispers
function MarketFinder:OnWhisper(event, message, sender)
    -- Skip if auto-sell is disabled
    if not self.db.profile.settings.enableAutoSell then
        return
    end
    
    -- Check if this is a buy request
    local item, price = message:match("WTS (.+) for (%d+)g")
    if item and price then
        local copperPrice = tonumber(price) * 10000
        self:ProcessBuyRequest(sender, item, copperPrice)
    end
end

-- New: Handle trade requests
function MarketFinder:OnTradeRequest(event, requester)
    -- Skip if auto-sell is disabled
    if not self.db.profile.settings.enableAutoSell then
        return
    end
    
    -- In a real implementation, we would check if we want to trade with this player
    -- For now, we'll just notify
    self:Print("Trade request from " .. requester .. ". Auto-sell would process this.")
end

-- Initialize minimap icon
function MarketFinder:InitializeMinimapIcon()
    if not ldb or not ldbIcon then return end
    
    local dataobj = ldb:NewDataObject("MarketFinder", {
        type = "data source",
        text = "MarketFinder",
        icon = "Interface\\Icons\\INV_Misc_Coin_01",
        OnClick = function(self, button)
            if button == "LeftButton" then
                MarketFinder:ToggleUI()
            elseif button == "RightButton" then
                MarketFinder:ShowHelp()
            end
        end,
        OnTooltipShow = function(tooltip)
            tooltip:AddLine("MarketFinder")
            tooltip:AddLine("Left-click: Toggle UI", 1, 1, 1)
            tooltip:AddLine("Right-click: Show help", 1, 1, 1)
        end,
    })
    
    ldbIcon:Register("MarketFinder", dataobj, self.db.profile.minimap)
end

-- Handle player login
function MarketFinder:OnPlayerLogin()
    -- Initialize the UI
    self:InitializeUI()
    self:Print("Ready to find markets! Visit an auction house to gather data.")
    
    -- Restore price history
    self:RestorePriceHistory()
end

-- Handle auction house opening
function MarketFinder:OnAuctionHouseShow()
    self:Print("Auction house detected. Gathering market data...")
    -- In a real implementation, we would collect auction data here
    self:StartMarketScan()
end

-- Handle auction house closing
function MarketFinder:OnAuctionHouseClosed()
    self:Print("Finished gathering market data.")
end

-- Initialize the UI
function MarketFinder:InitializeUI()
    -- Create a slash command to toggle the UI
    SLASH_MARKETFINDER1 = "/marketfinder"
    SLASH_MARKETFINDER2 = "/mfui"
    SlashCmdList["MARKETFINDER"] = function()
        self:ToggleUI()
    end
end

-- Toggle the UI
function MarketFinder:ToggleUI()
    if MarketFinderFrame:IsShown() then
        MarketFinderFrame:Hide()
    else
        MarketFinderFrame:Show()
    end
end

-- Handle chat commands
function MarketFinder:ChatCommand(input)
    local command, rest = input:match("^(%S*)%s*(.-)$")
    
    if command == "" or command == "help" then
        self:ShowHelp()
    elseif command == "find" then
        self:FindMarkets(rest)
    elseif command == "list" then
        self:ListMarkets()
    elseif command == "ui" then
        self:ToggleUI()
    elseif command == "favorites" then
        self:ListFavorites()
    elseif command == "shopping" then
        self:HandleShoppingCommand(rest)
    elseif command == "alerts" then
        self:HandleAlertsCommand(rest)
    elseif command == "autobuy" then
        self:HandleAutoBuyCommand(rest)
    elseif command == "autosell" then -- New: Auto-sell command
        self:HandleAutoSellCommand(rest)
    elseif command == "settings" then
        self:HandleSettingsCommand(rest)
    elseif command == "export" then
        self:ExportData(rest)
    else
        self:Print("Unknown command. Type /mf help for available commands.")
    end
end

-- Show help information
function MarketFinder:ShowHelp()
    self:Print("MarketFinder Commands:")
    self:Print("/mf - Show this help")
    self:Print("/mf find [item] - Find markets for a specific item")
    self:Print("/mf list - List nearby markets")
    self:Print("/mf ui - Toggle the MarketFinder UI")
    self:Print("/mf favorites - List favorite items")
    self:Print("/mf shopping [list] - Manage shopping lists")
    self:Print("/mf alerts [item] [price] - Manage price alerts")
    self:Print("/mf autobuy [item] [price] - Manage auto-buy rules")
    self:Print("/mf autosell [item] [price] - Manage auto-sell rules") -- New: Auto-sell help
    self:Print("/mf settings - Configure addon settings")
    self:Print("/mf export [data] - Export data")
end

-- Find markets for a specific item
function MarketFinder:FindMarkets(itemName)
    if itemName == "" then
        self:Print("Please specify an item to search for. Usage: /mf find [item]")
        return
    end
    
    -- Save to search history
    self:SaveToHistory(itemName)
    
    self:Print("Searching for markets for: " .. itemName)
    
    -- In a real implementation, this would query the auction house or other market data
    -- For now, we'll simulate the functionality with sample data
    local results = self:GenerateSampleResults(itemName)
    self:DisplayResults(itemName, results)
    
    -- Update price history
    self:UpdatePriceHistory(itemName, results)
    
    -- Check if we should auto-buy
    self:CheckAutoBuyOpportunity(itemName, results)
end

-- List nearby markets
function MarketFinder:ListMarkets()
    self:Print("Nearby markets:")
    self:Print("- Auction House (Stormwind)")
    self:Print("- Auction House (Orgrimmar)")
    self:Print("- Player Bazaar (Shattrath)")
    self:Print("- Trading Post (Everlook)")
    -- In a real implementation, this would scan for nearby players selling items
end

-- List favorite items
function MarketFinder:ListFavorites()
    local favorites = self.db.profile.favoriteItems
    if #favorites == 0 then
        self:Print("You have no favorite items. Use '/mf find [item]' to search for items and add them to favorites.")
        return
    end
    
    self:Print("Favorite items:")
    for i, item in ipairs(favorites) do
        self:Print("- " .. item)
    end
end

-- Search for markets (called from UI)
function MarketFinder:SearchForMarkets(itemName)
    if itemName == "" then
        self:Print("Please enter an item name to search for.")
        return
    end
    
    self:FindMarkets(itemName)
end

-- Generate sample results for demonstration
function MarketFinder:GenerateSampleResults(itemName)
    -- This is just sample data for demonstration purposes
    local results = {
        {
            item = itemName,
            minPrice = math.random(100, 1000),
            maxPrice = math.random(1000, 5000),
            avgPrice = math.random(500, 3000),
            quantity = math.random(1, 50),
            vendor = "Auction House",
            realm = GetRealmName()
        },
        {
            item = itemName,
            minPrice = math.random(50, 500),
            maxPrice = math.random(500, 3000),
            avgPrice = math.random(200, 2000),
            quantity = math.random(1, 30),
            vendor = "Player Merchant",
            realm = GetRealmName()
        },
        {
            item = itemName,
            minPrice = math.random(200, 800),
            maxPrice = math.random(800, 4000),
            avgPrice = math.random(400, 2500),
            quantity = math.random(1, 20),
            vendor = "Guild Bank",
            realm = GetRealmName()
        }
    }
    
    return results
end

-- Display search results
function MarketFinder:DisplayResults(itemName, results)
    self:Print("Market data for " .. itemName .. ":")
    
    for i, result in ipairs(results) do
        self:Print(result.vendor .. ":")
        self:Print("  Min Price: " .. GetCoinTextureString(result.minPrice))
        self:Print("  Max Price: " .. GetCoinTextureString(result.maxPrice))
        self:Print("  Avg Price: " .. GetCoinTextureString(result.avgPrice))
        self:Print("  Available: " .. result.quantity)
    end
    
    -- Add to favorites if not already there
    self:AddToFavorites(itemName)
end

-- Save item to search history
function MarketFinder:SaveToHistory(itemName)
    local history = self.db.profile.searchHistory
    -- Check if item is already in history
    for i, item in ipairs(history) do
        if item == itemName then
            -- Move to front of history
            table.remove(history, i)
            table.insert(history, 1, itemName)
            return
        end
    end
    
    -- Add to front of history
    table.insert(history, 1, itemName)
    
    -- Limit history to 10 items
    if #history > 10 then
        table.remove(history)
    end
end

-- Add item to favorites
function MarketFinder:AddToFavorites(itemName)
    local favorites = self.db.profile.favoriteItems
    -- Check if item is already in favorites
    for _, item in ipairs(favorites) do
        if item == itemName then
            return -- Already in favorites
        end
    end
    
    -- Add to favorites
    table.insert(favorites, itemName)
    self:Print(itemName .. " added to favorites.")
end

-- Handle shopping list commands
function MarketFinder:HandleShoppingCommand(input)
    local subcommand, rest = input:match("^(%S*)%s*(.-)$")
    
    if subcommand == "" or subcommand == "list" then
        self:ListShoppingLists()
    elseif subcommand == "create" then
        self:CreateShoppingList(rest)
    elseif subcommand == "add" then
        local listName, item = rest:match("^(%S+)%s+(.+)$")
        if listName and item then
            self:AddToShoppingList(listName, item)
        else
            self:Print("Usage: /mf shopping add [list] [item]")
        end
    elseif subcommand == "remove" then
        local listName, item = rest:match("^(%S+)%s+(.+)$")
        if listName and item then
            self:RemoveFromShoppingList(listName, item)
        else
            self:Print("Usage: /mf shopping remove [list] [item]")
        end
    elseif subcommand == "delete" then
        self:DeleteShoppingList(rest)
    elseif subcommand == "search" then
        self:SearchShoppingList(rest)
    else
        self:Print("Shopping list commands:")
        self:Print("/mf shopping list - List all shopping lists")
        self:Print("/mf shopping create [name] - Create a new shopping list")
        self:Print("/mf shopping add [list] [item] - Add item to shopping list")
        self:Print("/mf shopping remove [list] [item] - Remove item from shopping list")
        self:Print("/mf shopping delete [list] - Delete a shopping list")
        self:Print("/mf shopping search [list] - Search for all items in a shopping list")
    end
end

-- List all shopping lists
function MarketFinder:ListShoppingLists()
    local lists = self.db.profile.shoppingLists
    if not next(lists) then
        self:Print("You have no shopping lists. Use '/mf shopping create [name]' to create one.")
        return
    end
    
    self:Print("Shopping lists:")
    for name, items in pairs(lists) do
        self:Print("- " .. name .. " (" .. #items .. " items)")
    end
end

-- Create a new shopping list
function MarketFinder:CreateShoppingList(name)
    if name == "" then
        self:Print("Please specify a name for the shopping list. Usage: /mf shopping create [name]")
        return
    end
    
    if self.db.profile.shoppingLists[name] then
        self:Print("Shopping list '" .. name .. "' already exists.")
        return
    end
    
    self.db.profile.shoppingLists[name] = {}
    self:Print("Created shopping list '" .. name .. "'.")
end

-- Add item to shopping list
function MarketFinder:AddToShoppingList(listName, itemName)
    local lists = self.db.profile.shoppingLists
    if not lists[listName] then
        self:Print("Shopping list '" .. listName .. "' does not exist.")
        return
    end
    
    -- Check if item is already in the list
    for _, item in ipairs(lists[listName]) do
        if item == itemName then
            self:Print("'" .. itemName .. "' is already in '" .. listName .. "'.")
            return
        end
    end
    
    table.insert(lists[listName], itemName)
    self:Print("Added '" .. itemName .. "' to '" .. listName .. "'.")
end

-- Remove item from shopping list
function MarketFinder:RemoveFromShoppingList(listName, itemName)
    local lists = self.db.profile.shoppingLists
    if not lists[listName] then
        self:Print("Shopping list '" .. listName .. "' does not exist.")
        return
    end
    
    for i, item in ipairs(lists[listName]) do
        if item == itemName then
            table.remove(lists[listName], i)
            self:Print("Removed '" .. itemName .. "' from '" .. listName .. "'.")
            return
        end
    end
    
    self:Print("'" .. itemName .. "' not found in '" .. listName .. "'.")
end

-- Delete a shopping list
function MarketFinder:DeleteShoppingList(name)
    if name == "" then
        self:Print("Please specify a shopping list to delete. Usage: /mf shopping delete [name]")
        return
    end
    
    if not self.db.profile.shoppingLists[name] then
        self:Print("Shopping list '" .. name .. "' does not exist.")
        return
    end
    
    self.db.profile.shoppingLists[name] = nil
    self:Print("Deleted shopping list '" .. name .. "'.")
end

-- Search for all items in a shopping list
function MarketFinder:SearchShoppingList(name)
    local lists = self.db.profile.shoppingLists
    if not lists[name] then
        self:Print("Shopping list '" .. name .. "' does not exist.")
        return
    end
    
    if #lists[name] == 0 then
        self:Print("Shopping list '" .. name .. "' is empty.")
        return
    end
    
    self:Print("Searching for items in '" .. name .. "':")
    for _, item in ipairs(lists[name]) do
        self:Print("Searching for: " .. item)
        local results = self:GenerateSampleResults(item)
        self:DisplayResults(item, results)
    end
end

-- Handle price alerts commands
function MarketFinder:HandleAlertsCommand(input)
    local subcommand, rest = input:match("^(%S*)%s*(.-)$")
    
    if subcommand == "" or subcommand == "list" then
        self:ListPriceAlerts()
    elseif subcommand == "add" then
        local item, priceStr = rest:match("^(.-)%s+(%d+)$")
        if item and priceStr then
            local price = tonumber(priceStr)
            self:AddPriceAlert(item, price)
        else
            self:Print("Usage: /mf alerts add [item] [price]")
        end
    elseif subcommand == "remove" then
        self:RemovePriceAlert(rest)
    else
        self:Print("Price alerts commands:")
        self:Print("/mf alerts list - List all price alerts")
        self:Print("/mf alerts add [item] [price] - Add a price alert")
        self:Print("/mf alerts remove [item] - Remove a price alert")
    end
end

-- List all price alerts
function MarketFinder:ListPriceAlerts()
    local alerts = self.db.profile.priceAlerts
    if not next(alerts) then
        self:Print("You have no price alerts. Use '/mf alerts add [item] [price]' to create one.")
        return
    end
    
    self:Print("Price alerts:")
    for item, price in pairs(alerts) do
        self:Print("- " .. item .. " at " .. GetCoinTextureString(price))
    end
end

-- Add a price alert
function MarketFinder:AddPriceAlert(itemName, price)
    self.db.profile.priceAlerts[itemName] = price
    self:Print("Added price alert for '" .. itemName .. "' at " .. GetCoinTextureString(price))
    
    -- Check if we should notify immediately
    self:CheckPriceAlert(itemName, price)
end

-- Remove a price alert
function MarketFinder:RemovePriceAlert(itemName)
    if not self.db.profile.priceAlerts[itemName] then
        self:Print("No price alert for '" .. itemName .. "'.")
        return
    end
    
    self.db.profile.priceAlerts[itemName] = nil
    self:Print("Removed price alert for '" .. itemName .. "'.")
end

-- Check if a price alert should trigger
function MarketFinder:CheckPriceAlert(itemName, targetPrice)
    -- In a real implementation, this would check current market prices
    -- For now, we'll just simulate with a random chance
    if math.random(1, 5) == 1 then
        self:Print("ALERT: " .. itemName .. " is now available below your target price of " .. GetCoinTextureString(targetPrice) .. "!")
    end
end

-- Handle auto-buy commands
function MarketFinder:HandleAutoBuyCommand(input)
    local subcommand, rest = input:match("^(%S*)%s*(.-)$")
    
    if subcommand == "" or subcommand == "list" then
        self:ListAutoBuyRules()
    elseif subcommand == "add" then
        local item, priceStr = rest:match("^(.-)%s+(%d+)$")
        if item and priceStr then
            local price = tonumber(priceStr)
            self:AddAutoBuyRule(item, price)
        else
            self:Print("Usage: /mf autobuy add [item] [price]")
        end
    elseif subcommand == "remove" then
        self:RemoveAutoBuyRule(rest)
    elseif subcommand == "enable" then
        self:SetAutoBuyEnabled(true)
    elseif subcommand == "disable" then
        self:SetAutoBuyEnabled(false)
    else
        self:Print("Auto-buy commands:")
        self:Print("/mf autobuy list - List all auto-buy rules")
        self:Print("/mf autobuy add [item] [price] - Add an auto-buy rule")
        self:Print("/mf autobuy remove [item] - Remove an auto-buy rule")
        self:Print("/mf autobuy enable - Enable auto-buy feature")
        self:Print("/mf autobuy disable - Disable auto-buy feature")
    end
end

-- List all auto-buy rules
function MarketFinder:ListAutoBuyRules()
    local rules = self.db.profile.autoBuyRules
    if not next(rules) then
        self:Print("You have no auto-buy rules. Use '/mf autobuy add [item] [price]' to create one.")
        return
    end
    
    self:Print("Auto-buy rules:")
    for item, price in pairs(rules) do
        self:Print("- " .. item .. " at " .. GetCoinTextureString(price))
    end
    
    local settings = self.db.profile.settings
    self:Print("Auto-buy is " .. (settings.enableAutoBuy and "ENABLED" or "DISABLED"))
    self:Print("Max auto-buy price: " .. GetCoinTextureString(settings.maxAutoBuyPrice))
    self:Print("Auto-buy stack size: " .. settings.autoBuyStackSize)
end

-- Add an auto-buy rule
function MarketFinder:AddAutoBuyRule(itemName, price)
    -- Check if price is within limits
    if price > self.db.profile.settings.maxAutoBuyPrice then
        self:Print("Price exceeds maximum auto-buy limit of " .. GetCoinTextureString(self.db.profile.settings.maxAutoBuyPrice))
        return
    end
    
    self.db.profile.autoBuyRules[itemName] = price
    self:Print("Added auto-buy rule for '" .. itemName .. "' at " .. GetCoinTextureString(price))
    
    -- Check if we should buy immediately
    self:CheckAutoBuyOpportunity(itemName, self:GenerateSampleResults(itemName))
end

-- Remove an auto-buy rule
function MarketFinder:RemoveAutoBuyRule(itemName)
    if not self.db.profile.autoBuyRules[itemName] then
        self:Print("No auto-buy rule for '" .. itemName .. "'.")
        return
    end
    
    self.db.profile.autoBuyRules[itemName] = nil
    self:Print("Removed auto-buy rule for '" .. itemName .. "'.")
end

-- Enable/disable auto-buy
function MarketFinder:SetAutoBuyEnabled(enabled)
    self.db.profile.settings.enableAutoBuy = enabled
    if enabled then
        self:Print("Auto-buy feature enabled.")
        self:StartAutoBuyTimer()
    else
        self:Print("Auto-buy feature disabled.")
        if self.autoBuyTimer then
            self:CancelTimer(self.autoBuyTimer)
            self.autoBuyTimer = nil
        end
    end
end

-- Check for auto-buy opportunities
function MarketFinder:CheckAutoBuyOpportunity(itemName, results)
    -- Skip if auto-buy is disabled
    if not self.db.profile.settings.enableAutoBuy then
        return
    end
    
    -- Check if we have an auto-buy rule for this item
    local targetPrice = self.db.profile.autoBuyRules[itemName]
    if not targetPrice then
        return
    end
    
    -- Check if any vendor has the item below our target price
    for _, result in ipairs(results) do
        if result.minPrice <= targetPrice and result.quantity > 0 then
            self:ExecuteAutoBuy(itemName, result)
            return
        end
    end
end

-- Execute auto-buy
function MarketFinder:ExecuteAutoBuy(itemName, marketData)
    -- Check if we have enough money
    local playerMoney = GetMoney() -- In a real implementation, this would get player's money
    local totalPrice = marketData.minPrice * self.db.profile.settings.autoBuyStackSize
    
    if playerMoney < totalPrice then
        self:Print("Not enough money to auto-buy " .. itemName .. ". Need " .. GetCoinTextureString(totalPrice) .. ", have " .. GetCoinTextureString(playerMoney))
        return
    end
    
    -- Check if price is still within our maximum limit
    if marketData.minPrice > self.db.profile.settings.maxAutoBuyPrice then
        self:Print("Current price for " .. itemName .. " exceeds maximum auto-buy limit.")
        return
    end
    
    -- Execute the purchase
    self:Print("AUTO-BUY: Purchasing " .. self.db.profile.settings.autoBuyStackSize .. "x " .. itemName .. " from " .. marketData.vendor .. " for " .. GetCoinTextureString(marketData.minPrice) .. " each")
    
    -- In a real implementation, this would execute the actual purchase
    -- For now, we'll just simulate it
    self:Print("Purchase completed successfully!")
    
    -- Remove the rule if we only wanted to buy once
    -- In a real implementation, we might want to keep the rule for ongoing purchases
end

-- Start auto-buy timer
function MarketFinder:StartAutoBuyTimer()
    if not self.db.profile.settings.enableAutoBuy then
        return
    end
    
    if self.autoBuyTimer then
        self:CancelTimer(self.autoBuyTimer)
    end
    
    -- Check for auto-buy opportunities every 30 seconds
    self.autoBuyTimer = self:ScheduleRepeatingTimer("PerformAutoBuyCheck", 30)
end

-- Perform auto-buy check
function MarketFinder:PerformAutoBuyCheck()
    -- In a real implementation, this would scan the market for items matching our rules
    -- For now, we'll just notify that the check is happening
    self:DebugPrint("Performing auto-buy check...")
    
    -- Check favorite items for opportunities
    for _, item in ipairs(self.db.profile.favoriteItems) do
        local results = self:GenerateSampleResults(item)
        self:CheckAutoBuyOpportunity(item, results)
    end
end

-- New: Handle auto-sell commands
function MarketFinder:HandleAutoSellCommand(input)
    local subcommand, rest = input:match("^(%S*)%s*(.-)$")
    
    if subcommand == "" or subcommand == "list" then
        self:ListAutoSellRules()
    elseif subcommand == "add" then
        local item, priceStr = rest:match("^(.-)%s+(%d+)$")
        if item and priceStr then
            local price = tonumber(priceStr)
            self:AddAutoSellRule(item, price)
        else
            self:Print("Usage: /mf autosell add [item] [price]")
        end
    elseif subcommand == "remove" then
        self:RemoveAutoSellRule(rest)
    elseif subcommand == "enable" then
        self:SetAutoSellEnabled(true)
    elseif subcommand == "disable" then
        self:SetAutoSellEnabled(false)
    else
        self:Print("Auto-sell commands:")
        self:Print("/mf autosell list - List all auto-sell rules")
        self:Print("/mf autosell add [item] [price] - Add an auto-sell rule")
        self:Print("/mf autosell remove [item] - Remove an auto-sell rule")
        self:Print("/mf autosell enable - Enable auto-sell feature")
        self:Print("/mf autosell disable - Disable auto-sell feature")
    end
end

-- New: List all auto-sell rules
function MarketFinder:ListAutoSellRules()
    local rules = self.db.profile.autoSellRules
    if not next(rules) then
        self:Print("You have no auto-sell rules. Use '/mf autosell add [item] [price]' to create one.")
        return
    end
    
    self:Print("Auto-sell rules:")
    for item, price in pairs(rules) do
        self:Print("- " .. item .. " at " .. GetCoinTextureString(price))
    end
    
    local settings = self.db.profile.settings
    self:Print("Auto-sell is " .. (settings.enableAutoSell and "ENABLED" or "DISABLED"))
    self:Print("Min auto-sell price: " .. GetCoinTextureString(settings.minSellPrice))
    self:Print("Auto-sell stack size: " .. settings.autoSellStackSize)
    self:Print("Accept below market: " .. (settings.acceptBelowMarket * 100) .. "%")
end

-- New: Add an auto-sell rule
function MarketFinder:AddAutoSellRule(itemName, price)
    -- Check if price is above minimum
    if price < self.db.profile.settings.minSellPrice then
        self:Print("Price is below minimum auto-sell limit of " .. GetCoinTextureString(self.db.profile.settings.minSellPrice))
        return
    end
    
    self.db.profile.autoSellRules[itemName] = price
    self:Print("Added auto-sell rule for '" .. itemName .. "' at " .. GetCoinTextureString(price))
end

-- New: Remove an auto-sell rule
function MarketFinder:RemoveAutoSellRule(itemName)
    if not self.db.profile.autoSellRules[itemName] then
        self:Print("No auto-sell rule for '" .. itemName .. "'.")
        return
    end
    
    self.db.profile.autoSellRules[itemName] = nil
    self:Print("Removed auto-sell rule for '" .. itemName .. "'.")
end

-- New: Enable/disable auto-sell
function MarketFinder:SetAutoSellEnabled(enabled)
    self.db.profile.settings.enableAutoSell = enabled
    if enabled then
        self:Print("Auto-sell feature enabled.")
        self:StartAutoSellTimer()
    else
        self:Print("Auto-sell feature disabled.")
        if self.autoSellTimer then
            self:CancelTimer(self.autoSellTimer)
            self.autoSellTimer = nil
        end
    end
end

-- New: Process buy request from player
function MarketFinder:ProcessBuyRequest(player, itemName, offerPrice)
    -- Skip if auto-sell is disabled
    if not self.db.profile.settings.enableAutoSell then
        return
    end
    
    -- Check if we have an auto-sell rule for this item
    local targetPrice = self.db.profile.autoSellRules[itemName]
    if not targetPrice then
        -- Check if this is a rare item we might want to sell
        if self:IsRareItem(itemName) then
            self:Print(player .. " wants to buy rare item " .. itemName .. " for " .. GetCoinTextureString(offerPrice))
            -- In a real implementation, we would check if this is a good deal
            self:EvaluateSellOpportunity(player, itemName, offerPrice)
        end
        return
    end
    
    -- Check if the offer is acceptable
    local marketPrice = self:GetMarketPrice(itemName)
    local acceptThreshold = marketPrice * self.db.profile.settings.acceptBelowMarket
    
    if offerPrice >= targetPrice or offerPrice >= acceptThreshold then
        self:Print("ACCEPTED: " .. player .. " wants to buy " .. itemName .. " for " .. GetCoinTextureString(offerPrice))
        self:ExecuteAutoSell(player, itemName, offerPrice)
    else
        self:Print("REJECTED: " .. player .. " offer for " .. itemName .. " (" .. GetCoinTextureString(offerPrice) .. ") is below our threshold (" .. GetCoinTextureString(acceptThreshold) .. ")")
    end
end

-- New: Check if an item is rare
function MarketFinder:IsRareItem(itemName)
    -- In a real implementation, this would check item quality
    -- For now, we'll just simulate with a random chance
    return math.random(1, 10) <= 3 -- 30% chance of being rare
end

-- New: Get market price for an item
function MarketFinder:GetMarketPrice(itemName)
    -- In a real implementation, this would get the current market price
    -- For now, we'll just return a simulated price
    return math.random(1000, 10000)
end

-- New: Evaluate sell opportunity for rare items
function MarketFinder:EvaluateSellOpportunity(player, itemName, offerPrice)
    local marketPrice = self:GetMarketPrice(itemName)
    
    -- Accept if offer is at least 50% of market value
    if offerPrice >= marketPrice * 0.5 then
        self:Print("ACCEPTED RARE: " .. player .. " wants to buy rare item " .. itemName .. " for " .. GetCoinTextureString(offerPrice) .. " (market: " .. GetCoinTextureString(marketPrice) .. ")")
        self:ExecuteAutoSell(player, itemName, offerPrice)
    else
        self:Print("REJECTED RARE: " .. player .. " offer for " .. itemName .. " (" .. GetCoinTextureString(offerPrice) .. ") is below 50% of market value (" .. GetCoinTextureString(marketPrice) .. ")")
    end
end

-- New: Execute auto-sell
function MarketFinder:ExecuteAutoSell(player, itemName, price)
    -- In a real implementation, this would initiate a trade with the player
    -- For now, we'll just simulate it
    self:Print("AUTO-SELL: Selling " .. self.db.profile.settings.autoSellStackSize .. "x " .. itemName .. " to " .. player .. " for " .. GetCoinTextureString(price) .. " each")
    self:Print("Trade would be initiated with " .. player .. " now.")
end

-- New: Start auto-sell timer
function MarketFinder:StartAutoSellTimer()
    if not self.db.profile.settings.enableAutoSell then
        return
    end
    
    if self.autoSellTimer then
        self:CancelTimer(self.autoSellTimer)
    end
    
    -- Check for auto-sell opportunities every 60 seconds
    self.autoSellTimer = self:ScheduleRepeatingTimer("PerformAutoSellCheck", 60)
end

-- New: Perform auto-sell check
function MarketFinder:PerformAutoSellCheck()
    -- In a real implementation, this would check inventory for items to sell
    -- For now, we'll just notify that the check is happening
    self:DebugPrint("Performing auto-sell check...")
    
    -- Check inventory for rare items
    self:CheckInventoryForRareItems()
end

-- New: Check inventory for rare items
function MarketFinder:CheckInventoryForRareItems()
    -- In a real implementation, this would scan the player's inventory
    -- For now, we'll just simulate with a random chance
    if math.random(1, 5) == 1 then
        local rareItem = "Rare Item " .. math.random(1, 100)
        local marketPrice = self:GetMarketPrice(rareItem)
        self:Print("Found rare item in inventory: " .. rareItem .. " (market value: " .. GetCoinTextureString(marketPrice) .. ")")
    end
end

-- Handle settings commands
function MarketFinder:HandleSettingsCommand(input)
    local setting, value = input:match("^(%S*)%s*(.-)$")
    
    if setting == "" or setting == "show" then
        self:ShowSettings()
    elseif setting == "autoscan" then
        if value == "on" then
            self:SetAutoScan(true)
        elseif value == "off" then
            self:SetAutoScan(false)
        else
            self:Print("Usage: /mf settings autoscan [on|off]")
        end
    elseif setting == "interval" then
        local interval = tonumber(value)
        if interval then
            self:SetScanInterval(interval)
        else
            self:Print("Usage: /mf settings interval [minutes]")
        end
    elseif setting == "minimap" then
        if value == "on" then
            self:SetMinimapIcon(true)
        elseif value == "off" then
            self:SetMinimapIcon(false)
        else
            self:Print("Usage: /mf settings minimap [on|off]")
        end
    elseif setting == "autobuy" then
        if value == "on" then
            self:SetAutoBuyEnabled(true)
        elseif value == "off" then
            self:SetAutoBuyEnabled(false)
        else
            self:Print("Usage: /mf settings autobuy [on|off]")
        end
    elseif setting == "maxprice" then
        local price = tonumber(value)
        if price then
            self:SetMaxAutoBuyPrice(price)
        else
            self:Print("Usage: /mf settings maxprice [price]")
        end
    elseif setting == "stacksize" then
        local size = tonumber(value)
        if size and size > 0 then
            self:SetAutoBuyStackSize(size)
        else
            self:Print("Usage: /mf settings stacksize [number]")
        end
    elseif setting == "autosell" then -- New: Auto-sell settings
        if value == "on" then
            self:SetAutoSellEnabled(true)
        elseif value == "off" then
            self:SetAutoSellEnabled(false)
        else
            self:Print("Usage: /mf settings autosell [on|off]")
        end
    elseif setting == "minsellprice" then -- New: Min sell price
        local price = tonumber(value)
        if price then
            self:SetMinAutoSellPrice(price)
        else
            self:Print("Usage: /mf settings minsellprice [price]")
        end
    elseif setting == "sellstacksize" then -- New: Sell stack size
        local size = tonumber(value)
        if size and size > 0 then
            self:SetAutoSellStackSize(size)
        else
            self:Print("Usage: /mf settings sellstacksize [number]")
        end
    elseif setting == "acceptbelow" then -- New: Accept below market
        local percent = tonumber(value)
        if percent and percent > 0 and percent <= 100 then
            self:SetAcceptBelowMarket(percent / 100)
        else
            self:Print("Usage: /mf settings acceptbelow [percent]")
        end
    else
        self:Print("Settings commands:")
        self:Print("/mf settings show - Show current settings")
        self:Print("/mf settings autoscan [on|off] - Enable/disable auto scanning")
        self:Print("/mf settings interval [minutes] - Set auto scan interval")
        self:Print("/mf settings minimap [on|off] - Show/hide minimap icon")
        self:Print("/mf settings autobuy [on|off] - Enable/disable auto-buy feature")
        self:Print("/mf settings maxprice [price] - Set maximum auto-buy price")
        self:Print("/mf settings stacksize [number] - Set auto-buy stack size")
        self:Print("/mf settings autosell [on|off] - Enable/disable auto-sell feature") -- New: Auto-sell setting
        self:Print("/mf settings minsellprice [price] - Set minimum auto-sell price") -- New: Min sell price setting
        self:Print("/mf settings sellstacksize [number] - Set auto-sell stack size") -- New: Sell stack size setting
        self:Print("/mf settings acceptbelow [percent] - Set % below market to accept") -- New: Accept below setting
    end
end

-- Show current settings
function MarketFinder:ShowSettings()
    local settings = self.db.profile.settings
    self:Print("MarketFinder Settings:")
    self:Print("Auto Scan: " .. (settings.autoScan and "Enabled" or "Disabled"))
    self:Print("Scan Interval: " .. settings.scanInterval .. " minutes")
    self:Print("Minimap Icon: " .. (settings.showMinimapIcon and "Visible" or "Hidden"))
    self:Print("Auto-Buy: " .. (settings.enableAutoBuy and "Enabled" or "Disabled"))
    self:Print("Max Auto-Buy Price: " .. GetCoinTextureString(settings.maxAutoBuyPrice))
    self:Print("Auto-Buy Stack Size: " .. settings.autoBuyStackSize)
    self:Print("Auto-Sell: " .. (settings.enableAutoSell and "Enabled" or "Disabled")) -- New: Auto-sell setting
    self:Print("Min Auto-Sell Price: " .. GetCoinTextureString(settings.minSellPrice)) -- New: Min sell price setting
    self:Print("Auto-Sell Stack Size: " .. settings.autoSellStackSize) -- New: Sell stack size setting
    self:Print("Accept Below Market: " .. (settings.acceptBelowMarket * 100) .. "%") -- New: Accept below setting
end

-- Set auto scan
function MarketFinder:SetAutoScan(enabled)
    self.db.profile.settings.autoScan = enabled
    if enabled then
        self:StartAutoScan()
        self:Print("Auto scan enabled.")
    else
        if self.scanTimer then
            self:CancelTimer(self.scanTimer)
            self.scanTimer = nil
        end
        self:Print("Auto scan disabled.")
    end
end

-- Set scan interval
function MarketFinder:SetScanInterval(minutes)
    if minutes < 1 then
        self:Print("Scan interval must be at least 1 minute.")
        return
    end
    
    self.db.profile.settings.scanInterval = minutes
    self:Print("Scan interval set to " .. minutes .. " minutes.")
    
    -- Restart timer if auto scan is enabled
    if self.db.profile.settings.autoScan and self.scanTimer then
        self:CancelTimer(self.scanTimer)
        self:StartAutoScan()
    end
end

-- Set minimap icon visibility
function MarketFinder:SetMinimapIcon(visible)
    self.db.profile.settings.showMinimapIcon = visible
    if ldbIcon then
        if visible then
            ldbIcon:Show("MarketFinder")
            self:Print("Minimap icon shown.")
        else
            ldbIcon:Hide("MarketFinder")
            self:Print("Minimap icon hidden.")
        end
    end
end

-- Set maximum auto-buy price
function MarketFinder:SetMaxAutoBuyPrice(price)
    if price <= 0 then
        self:Print("Maximum auto-buy price must be greater than 0.")
        return
    end
    
    self.db.profile.settings.maxAutoBuyPrice = price
    self:Print("Maximum auto-buy price set to " .. GetCoinTextureString(price))
end

-- Set auto-buy stack size
function MarketFinder:SetAutoBuyStackSize(size)
    if size <= 0 then
        self:Print("Auto-buy stack size must be greater than 0.")
        return
    end
    
    self.db.profile.settings.autoBuyStackSize = size
    self:Print("Auto-buy stack size set to " .. size)
end

-- New: Set minimum auto-sell price
function MarketFinder:SetMinAutoSellPrice(price)
    if price <= 0 then
        self:Print("Minimum auto-sell price must be greater than 0.")
        return
    end
    
    self.db.profile.settings.minSellPrice = price
    self:Print("Minimum auto-sell price set to " .. GetCoinTextureString(price))
end

-- New: Set auto-sell stack size
function MarketFinder:SetAutoSellStackSize(size)
    if size <= 0 then
        self:Print("Auto-sell stack size must be greater than 0.")
        return
    end
    
    self.db.profile.settings.autoSellStackSize = size
    self:Print("Auto-sell stack size set to " .. size)
end

-- New: Set accept below market percentage
function MarketFinder:SetAcceptBelowMarket(percent)
    if percent <= 0 or percent > 1 then
        self:Print("Accept below market percentage must be between 0 and 100.")
        return
    end
    
    self.db.profile.settings.acceptBelowMarket = percent
    self:Print("Accept below market set to " .. (percent * 100) .. "%")
end

-- Start auto scan timer
function MarketFinder:StartAutoScan()
    if self.scanTimer then
        self:CancelTimer(self.scanTimer)
    end
    
    local interval = self.db.profile.settings.scanInterval * 60 -- Convert to seconds
    self.scanTimer = self:ScheduleRepeatingTimer("PerformAutoScan", interval)
end

-- Perform auto scan
function MarketFinder:PerformAutoScan()
    self:Print("Performing automatic market scan...")
    -- In a real implementation, this would scan favorite items or shopping lists
    -- For now, we'll just notify
    self:Print("Auto scan complete.")
end

-- Export data
function MarketFinder:ExportData(dataType)
    if dataType == "" or dataType == "favorites" then
        self:ExportFavorites()
    elseif dataType == "history" then
        self:ExportHistory()
    elseif dataType == "prices" then
        self:ExportPriceData()
    else
        self:Print("Export commands:")
        self:Print("/mf export favorites - Export favorite items")
        self:Print("/mf export history - Export search history")
        self:Print("/mf export prices - Export price history")
    end
end

-- Export favorites
function MarketFinder:ExportFavorites()
    local favorites = self.db.profile.favoriteItems
    if #favorites == 0 then
        self:Print("No favorite items to export.")
        return
    end
    
    local exportText = "Favorite Items:\n"
    for i, item in ipairs(favorites) do
        exportText = exportText .. i .. ". " .. item .. "\n"
    end
    
    self:Print("Exporting favorites to chat:")
    self:Print(exportText)
end

-- Export history
function MarketFinder:ExportHistory()
    local history = self.db.profile.searchHistory
    if #history == 0 then
        self:Print("No search history to export.")
        return
    end
    
    local exportText = "Search History:\n"
    for i, item in ipairs(history) do
        exportText = exportText .. i .. ". " .. item .. "\n"
    end
    
    self:Print("Exporting search history to chat:")
    self:Print(exportText)
end

-- Export price data
function MarketFinder:ExportPriceData()
    self:Print("Price data export would be implemented here.")
    -- In a real implementation, this would export price history data
end

-- Start market scan
function MarketFinder:StartMarketScan()
    -- In a real implementation, this would scan the auction house
    self:Print("Market scan started...")
end

-- Update price history
function MarketFinder:UpdatePriceHistory(itemName, results)
    if not self.priceHistory[itemName] then
        self.priceHistory[itemName] = {}
    end
    
    -- Add current timestamp and prices
    local timestamp = time()
    for _, result in ipairs(results) do
        table.insert(self.priceHistory[itemName], {
            timestamp = timestamp,
            vendor = result.vendor,
            minPrice = result.minPrice,
            maxPrice = result.maxPrice,
            avgPrice = result.avgPrice
        })
    end
    
    -- Limit history to 100 entries per item
    if #self.priceHistory[itemName] > 100 then
        table.remove(self.priceHistory[itemName], 1)
    end
end

-- Save price history
function MarketFinder:SavePriceHistory()
    -- In a real implementation, this would save to the database
    self:Print("Price history saved.")
end

-- Restore price history
function MarketFinder:RestorePriceHistory()
    -- In a real implementation, this would restore from the database
    self:Print("Price history restored.")
end

-- Debug print function
function MarketFinder:DebugPrint(message)
    -- Only print debug messages if debugging is enabled
    -- In a real implementation, we might have a debug setting
    -- self:Print("[DEBUG] " .. message)
end

-- Helper function to format coin values (simulated)
function GetCoinTextureString(amount)
    -- In a real implementation, this would use WoW's coin formatting functions
    -- For now, we'll just format as gold
    local gold = math.floor(amount / 10000)
    local silver = math.floor((amount % 10000) / 100)
    local copper = amount % 100
    
    local result = ""
    if gold > 0 then
        result = result .. gold .. "g "
    end
    if silver > 0 then
        result = result .. silver .. "s "
    end
    if copper > 0 or result == "" then
        result = result .. copper .. "c"
    end
    
    return result
end

-- Show search tab
function MarketFinder:ShowSearchTab()
    MarketFinderSearchFrame:Show()
    MarketFinderShoppingFrame:Hide()
    MarketFinderAlertsFrame:Hide()
    MarketFinderAutoBuyFrame:Hide()
    MarketFinderAutoSellFrame:Hide() -- New: Hide auto-sell frame
    MarketFinderSettingsFrame:Hide()
    
    -- Update button states
    MarketFinderSearchTab:LockHighlight()
    MarketFinderShoppingTab:UnlockHighlight()
    MarketFinderAlertsTab:UnlockHighlight()
    MarketFinderAutoBuyTab:UnlockHighlight()
    MarketFinderAutoSellTab:UnlockHighlight() -- New: Unlock auto-sell tab
    MarketFinderSettingsTab:UnlockHighlight()
end

-- Show shopping lists tab
function MarketFinder:ShowShoppingTab()
    MarketFinderSearchFrame:Hide()
    MarketFinderShoppingFrame:Show()
    MarketFinderAlertsFrame:Hide()
    MarketFinderAutoBuyFrame:Hide()
    MarketFinderAutoSellFrame:Hide() -- New: Hide auto-sell frame
    MarketFinderSettingsFrame:Hide()
    
    -- Update button states
    MarketFinderSearchTab:UnlockHighlight()
    MarketFinderShoppingTab:LockHighlight()
    MarketFinderAlertsTab:UnlockHighlight()
    MarketFinderAutoBuyTab:UnlockHighlight()
    MarketFinderAutoSellTab:UnlockHighlight() -- New: Unlock auto-sell tab
    MarketFinderSettingsTab:UnlockHighlight()
    
    -- Refresh shopping lists display
    self:RefreshShoppingLists()
end

-- Show price alerts tab
function MarketFinder:ShowAlertsTab()
    MarketFinderSearchFrame:Hide()
    MarketFinderShoppingFrame:Hide()
    MarketFinderAlertsFrame:Show()
    MarketFinderAutoBuyFrame:Hide()
    MarketFinderAutoSellFrame:Hide() -- New: Hide auto-sell frame
    MarketFinderSettingsFrame:Hide()
    
    -- Update button states
    MarketFinderSearchTab:UnlockHighlight()
    MarketFinderShoppingTab:UnlockHighlight()
    MarketFinderAlertsTab:LockHighlight()
    MarketFinderAutoBuyTab:UnlockHighlight()
    MarketFinderAutoSellTab:UnlockHighlight() -- New: Unlock auto-sell tab
    MarketFinderSettingsTab:UnlockHighlight()
    
    -- Refresh alerts display
    self:RefreshPriceAlerts()
end

-- Show auto-buy tab
function MarketFinder:ShowAutoBuyTab()
    MarketFinderSearchFrame:Hide()
    MarketFinderShoppingFrame:Hide()
    MarketFinderAlertsFrame:Hide()
    MarketFinderAutoBuyFrame:Show()
    MarketFinderAutoSellFrame:Hide() -- New: Hide auto-sell frame
    MarketFinderSettingsFrame:Hide()
    
    -- Update button states
    MarketFinderSearchTab:UnlockHighlight()
    MarketFinderShoppingTab:UnlockHighlight()
    MarketFinderAlertsTab:UnlockHighlight()
    MarketFinderAutoBuyTab:LockHighlight()
    MarketFinderAutoSellTab:UnlockHighlight() -- New: Unlock auto-sell tab
    MarketFinderSettingsTab:UnlockHighlight()
    
    -- Refresh auto-buy display
    self:RefreshAutoBuyRules()
end

-- New: Show auto-sell tab
function MarketFinder:ShowAutoSellTab()
    MarketFinderSearchFrame:Hide()
    MarketFinderShoppingFrame:Hide()
    MarketFinderAlertsFrame:Hide()
    MarketFinderAutoBuyFrame:Hide()
    MarketFinderAutoSellFrame:Show()
    MarketFinderSettingsFrame:Hide()
    
    -- Update button states
    MarketFinderSearchTab:UnlockHighlight()
    MarketFinderShoppingTab:UnlockHighlight()
    MarketFinderAlertsTab:UnlockHighlight()
    MarketFinderAutoBuyTab:UnlockHighlight()
    MarketFinderAutoSellTab:LockHighlight()
    MarketFinderSettingsTab:UnlockHighlight()
    
    -- Refresh auto-sell display
    self:RefreshAutoSellRules()
end

-- Show settings tab
function MarketFinder:ShowSettingsTab()
    MarketFinderSearchFrame:Hide()
    MarketFinderShoppingFrame:Hide()
    MarketFinderAlertsFrame:Hide()
    MarketFinderAutoBuyFrame:Hide()
    MarketFinderAutoSellFrame:Hide() -- New: Hide auto-sell frame
    MarketFinderSettingsFrame:Show()
    
    -- Update button states
    MarketFinderSearchTab:UnlockHighlight()
    MarketFinderShoppingTab:UnlockHighlight()
    MarketFinderAlertsTab:UnlockHighlight()
    MarketFinderAutoBuyTab:UnlockHighlight()
    MarketFinderAutoSellTab:UnlockHighlight() -- New: Unlock auto-sell tab
    MarketFinderSettingsTab:LockHighlight()
    
    -- Update settings controls
    self:UpdateSettingsControls()
end

-- Refresh shopping lists display
function MarketFinder:RefreshShoppingLists()
    -- In a real implementation, this would populate the shopping lists frame
    MarketFinderShoppingListsText:SetText("Shopping lists would be displayed here.")
end

-- Refresh price alerts display
function MarketFinder:RefreshPriceAlerts()
    -- In a real implementation, this would populate the alerts frame
    MarketFinderAlertsListText:SetText("Price alerts would be displayed here.")
end

-- Refresh auto-buy rules display
function MarketFinder:RefreshAutoBuyRules()
    -- In a real implementation, this would populate the auto-buy frame
    MarketFinderAutoBuyListText:SetText("Auto-buy rules would be displayed here.")
end

-- New: Refresh auto-sell rules display
function MarketFinder:RefreshAutoSellRules()
    -- In a real implementation, this would populate the auto-sell frame
    MarketFinderAutoSellListText:SetText("Auto-sell rules would be displayed here.")
end

-- Update settings controls
function MarketFinder:UpdateSettingsControls()
    local settings = self.db.profile.settings
    MarketFinderAutoScanCheck:SetChecked(settings.autoScan)
    MarketFinderMinimapCheck:SetChecked(settings.showMinimapIcon)
    MarketFinderScanIntervalSlider:SetValue(settings.scanInterval)
    MarketFinderAutoBuyCheck:SetChecked(settings.enableAutoBuy)
    MarketFinderMaxPriceEditBox:SetText(tostring(settings.maxAutoBuyPrice))
    MarketFinderStackSizeEditBox:SetText(tostring(settings.autoBuyStackSize))
    MarketFinderAutoSellCheck:SetChecked(settings.enableAutoSell) -- New: Auto-sell checkbox
    MarketFinderMinSellPriceEditBox:SetText(tostring(settings.minSellPrice)) -- New: Min sell price editbox
    MarketFinderSellStackSizeEditBox:SetText(tostring(settings.autoSellStackSize)) -- New: Sell stack size editbox
    MarketFinderAcceptBelowEditBox:SetText(tostring(settings.acceptBelowMarket * 100)) -- New: Accept below editbox
end